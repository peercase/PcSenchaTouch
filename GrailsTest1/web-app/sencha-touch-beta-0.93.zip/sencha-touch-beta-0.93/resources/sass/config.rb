require 'compass-colors'

# Require any additional compass plugins here.
images_dir = 'img'
output_style = :compressed
environment = :production