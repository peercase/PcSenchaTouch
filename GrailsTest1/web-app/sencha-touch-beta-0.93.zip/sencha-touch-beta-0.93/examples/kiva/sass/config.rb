require 'compass-colors'

# Require any additional compass plugins here.
images_dir = '../../resources/img'
output_style = :compressed
environment = :production