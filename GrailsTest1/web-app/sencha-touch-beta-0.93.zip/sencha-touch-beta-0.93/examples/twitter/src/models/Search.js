Ext.regModel('Search', {
    fields: [
        {name: 'query', type: 'string'}
    ]
});