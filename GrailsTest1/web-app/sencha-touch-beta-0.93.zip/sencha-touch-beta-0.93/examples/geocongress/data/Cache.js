Geo.cache.Legislators = {
    bios: {},
    votes: {},
    bills: {}
};

Geo.cache.Committees = {};