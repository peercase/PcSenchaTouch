Solitaire.StackManager = new Ext.AbstractManager({
    typeName: 'stack'
});