Ext.data.ProxyMgr = new Ext.AbstractManager({
    
});